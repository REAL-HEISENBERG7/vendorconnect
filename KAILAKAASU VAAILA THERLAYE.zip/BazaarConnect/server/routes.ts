import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertMaterialRequestSchema, insertOrderSchema, insertSupplierInventorySchema, insertQuoteSchema } from "@shared/schema";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

// Middleware to verify JWT token
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.sendStatus(401);
  }

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Auth routes
  app.post("/api/auth/signup", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists with this email" });
      }

      const existingUsername = await storage.getUserByUsername(userData.username);
      if (existingUsername) {
        return res.status(400).json({ message: "Username already taken" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
      });

      const { password, ...userWithoutPassword } = user;
      const token = jwt.sign({ userId: user.id, userType: user.userType }, JWT_SECRET);
      
      res.json({ user: userWithoutPassword, token });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(400).json({ message: "Invalid credentials" });
      }

      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(400).json({ message: "Invalid credentials" });
      }

      const { password: _, ...userWithoutPassword } = user;
      const token = jwt.sign({ userId: user.id, userType: user.userType }, JWT_SECRET);
      
      res.json({ user: userWithoutPassword, token });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/auth/me", authenticateToken, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Material routes
  app.get("/api/materials", async (req, res) => {
    try {
      const { search } = req.query;
      let materials;
      
      if (search) {
        materials = await storage.searchMaterials(search as string);
      } else {
        materials = await storage.getAllMaterials();
      }
      
      res.json(materials);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/materials/:id/suppliers", async (req, res) => {
    try {
      const { id } = req.params;
      const inventory = await storage.getInventoryByMaterial(id);
      
      // Get supplier details for each inventory item
      const suppliersWithInventory = await Promise.all(
        inventory.map(async (item) => {
          const supplier = await storage.getUser(item.supplierId);
          return {
            ...item,
            supplier: supplier ? { id: supplier.id, businessName: supplier.businessName, contactNumber: supplier.contactNumber } : null
          };
        })
      );
      
      res.json(suppliersWithInventory);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Material request routes
  app.get("/api/material-requests", authenticateToken, async (req: any, res) => {
    try {
      const requests = req.user.userType === 'vendor' 
        ? await storage.getMaterialRequests(req.user.userId)
        : await storage.getMaterialRequests();
      
      // Get material details for each request
      const requestsWithMaterials = await Promise.all(
        requests.map(async (request) => {
          const material = await storage.getMaterialById(request.materialId);
          const vendor = await storage.getUser(request.vendorId);
          return {
            ...request,
            material,
            vendor: vendor ? { id: vendor.id, businessName: vendor.businessName, contactNumber: vendor.contactNumber } : null
          };
        })
      );
      
      res.json(requestsWithMaterials);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/material-requests", authenticateToken, async (req: any, res) => {
    try {
      if (req.user.userType !== 'vendor') {
        return res.status(403).json({ message: "Only vendors can create material requests" });
      }

      const requestData = insertMaterialRequestSchema.parse({
        ...req.body,
        vendorId: req.user.userId,
      });
      
      const request = await storage.createMaterialRequest(requestData);
      res.json(request);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Supplier inventory routes
  app.get("/api/supplier/inventory", authenticateToken, async (req: any, res) => {
    try {
      if (req.user.userType !== 'supplier') {
        return res.status(403).json({ message: "Only suppliers can access inventory" });
      }

      const inventory = await storage.getSupplierInventory(req.user.userId);
      
      // Get material details for each inventory item
      const inventoryWithMaterials = await Promise.all(
        inventory.map(async (item) => {
          const material = await storage.getMaterialById(item.materialId);
          return { ...item, material };
        })
      );
      
      res.json(inventoryWithMaterials);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/supplier/inventory", authenticateToken, async (req: any, res) => {
    try {
      if (req.user.userType !== 'supplier') {
        return res.status(403).json({ message: "Only suppliers can add inventory" });
      }

      const inventoryData = insertSupplierInventorySchema.parse({
        ...req.body,
        supplierId: req.user.userId,
      });
      
      const item = await storage.createInventoryItem(inventoryData);
      res.json(item);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch("/api/supplier/inventory/:id", authenticateToken, async (req: any, res) => {
    try {
      if (req.user.userType !== 'supplier') {
        return res.status(403).json({ message: "Only suppliers can update inventory" });
      }

      const { id } = req.params;
      const updates = req.body;
      
      const item = await storage.updateInventoryItem(id, updates);
      if (!item) {
        return res.status(404).json({ message: "Inventory item not found" });
      }
      
      res.json(item);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Quote routes
  app.get("/api/quotes", authenticateToken, async (req: any, res) => {
    try {
      const { requestId } = req.query;
      
      let quotes;
      if (req.user.userType === 'supplier') {
        quotes = await storage.getQuotes(undefined, req.user.userId);
      } else if (requestId) {
        quotes = await storage.getQuotes(requestId as string);
      } else {
        quotes = await storage.getQuotes();
      }
      
      // Get supplier details for each quote
      const quotesWithSuppliers = await Promise.all(
        quotes.map(async (quote) => {
          const supplier = await storage.getUser(quote.supplierId);
          const request = await storage.getMaterialRequestById(quote.requestId);
          return {
            ...quote,
            supplier: supplier ? { id: supplier.id, businessName: supplier.businessName, contactNumber: supplier.contactNumber } : null,
            request
          };
        })
      );
      
      res.json(quotesWithSuppliers);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/quotes", authenticateToken, async (req: any, res) => {
    try {
      if (req.user.userType !== 'supplier') {
        return res.status(403).json({ message: "Only suppliers can create quotes" });
      }

      const quoteData = insertQuoteSchema.parse({
        ...req.body,
        supplierId: req.user.userId,
      });
      
      const quote = await storage.createQuote(quoteData);
      res.json(quote);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch("/api/quotes/:id", authenticateToken, async (req: any, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const quote = await storage.updateQuote(id, updates);
      if (!quote) {
        return res.status(404).json({ message: "Quote not found" });
      }
      
      res.json(quote);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Order routes
  app.get("/api/orders", authenticateToken, async (req: any, res) => {
    try {
      const orders = await storage.getOrders(req.user.userId, req.user.userType);
      
      // Get related details for each order
      const ordersWithDetails = await Promise.all(
        orders.map(async (order) => {
          const material = await storage.getMaterialById(order.materialId);
          const vendor = await storage.getUser(order.vendorId);
          const supplier = await storage.getUser(order.supplierId);
          return {
            ...order,
            material,
            vendor: vendor ? { id: vendor.id, businessName: vendor.businessName, contactNumber: vendor.contactNumber } : null,
            supplier: supplier ? { id: supplier.id, businessName: supplier.businessName, contactNumber: supplier.contactNumber } : null
          };
        })
      );
      
      res.json(ordersWithDetails);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/orders", authenticateToken, async (req: any, res) => {
    try {
      if (req.user.userType !== 'vendor') {
        return res.status(403).json({ message: "Only vendors can create orders" });
      }

      const orderData = insertOrderSchema.parse({
        ...req.body,
        vendorId: req.user.userId,
      });
      
      const order = await storage.createOrder(orderData);
      res.json(order);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch("/api/orders/:id", authenticateToken, async (req: any, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const order = await storage.updateOrder(id, updates);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      res.json(order);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Analytics routes
  app.get("/api/analytics/vendor/:id", authenticateToken, async (req: any, res) => {
    try {
      const { id } = req.params;
      
      if (req.user.userType !== 'vendor' || req.user.userId !== id) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const orders = await storage.getOrders(id, 'vendor');
      const requests = await storage.getMaterialRequests(id);
      
      const currentMonth = new Date().getMonth();
      const currentYear = new Date().getFullYear();
      
      const monthlyOrders = orders.filter(order => {
        const orderDate = new Date(order.createdAt);
        return orderDate.getMonth() === currentMonth && orderDate.getFullYear() === currentYear;
      });
      
      const monthlySpend = monthlyOrders.reduce((total, order) => total + parseFloat(order.totalAmount), 0);
      const activeOrders = orders.filter(order => !['delivered', 'cancelled'].includes(order.status)).length;
      
      // Get unique suppliers
      const supplierIds = new Set(orders.map(order => order.supplierId));
      
      // Calculate average delivery time
      const deliveredOrders = orders.filter(order => order.status === 'delivered' && order.actualDelivery);
      const avgDeliveryTime = deliveredOrders.length > 0 
        ? deliveredOrders.reduce((total, order) => {
            const created = new Date(order.createdAt);
            const delivered = new Date(order.actualDelivery!);
            return total + (delivered.getTime() - created.getTime());
          }, 0) / deliveredOrders.length / (1000 * 60 * 60 * 24) // Convert to days
        : 0;
      
      res.json({
        activeOrders,
        monthlySpend,
        suppliers: supplierIds.size,
        avgDelivery: `${avgDeliveryTime.toFixed(1)} days`,
        totalOrders: orders.length,
        totalRequests: requests.length
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/analytics/supplier/:id", authenticateToken, async (req: any, res) => {
    try {
      const { id } = req.params;
      
      if (req.user.userType !== 'supplier' || req.user.userId !== id) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const orders = await storage.getOrders(id, 'supplier');
      const inventory = await storage.getSupplierInventory(id);
      const quotes = await storage.getQuotes(undefined, id);
      
      const currentMonth = new Date().getMonth();
      const currentYear = new Date().getFullYear();
      
      const monthlyOrders = orders.filter(order => {
        const orderDate = new Date(order.createdAt);
        return orderDate.getMonth() === currentMonth && orderDate.getFullYear() === currentYear;
      });
      
      const monthlyRevenue = monthlyOrders.reduce((total, order) => total + parseFloat(order.totalAmount), 0);
      const activeOrders = orders.filter(order => !['delivered', 'cancelled'].includes(order.status)).length;
      
      // Calculate rating (simplified - in real app would be based on actual reviews)
      const rating = 4.8;
      
      res.json({
        activeOrders,
        monthlyRevenue,
        products: inventory.length,
        rating: `${rating}★`,
        totalOrders: orders.length,
        totalQuotes: quotes.length
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
