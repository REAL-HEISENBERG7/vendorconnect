import { 
  type User, 
  type InsertUser,
  type Material,
  type InsertMaterial,
  type SupplierInventory,
  type InsertSupplierInventory,
  type MaterialRequest,
  type InsertMaterialRequest,
  type Order,
  type InsertOrder,
  type Quote,
  type InsertQuote
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUsersByType(userType: 'vendor' | 'supplier'): Promise<User[]>;

  // Material operations
  getAllMaterials(): Promise<Material[]>;
  getMaterialById(id: string): Promise<Material | undefined>;
  createMaterial(material: InsertMaterial): Promise<Material>;
  searchMaterials(query: string): Promise<Material[]>;

  // Supplier inventory operations
  getSupplierInventory(supplierId: string): Promise<SupplierInventory[]>;
  getInventoryByMaterial(materialId: string): Promise<SupplierInventory[]>;
  createInventoryItem(item: InsertSupplierInventory): Promise<SupplierInventory>;
  updateInventoryItem(id: string, updates: Partial<SupplierInventory>): Promise<SupplierInventory | undefined>;

  // Material request operations
  getMaterialRequests(vendorId?: string): Promise<MaterialRequest[]>;
  getMaterialRequestById(id: string): Promise<MaterialRequest | undefined>;
  createMaterialRequest(request: InsertMaterialRequest): Promise<MaterialRequest>;
  updateMaterialRequest(id: string, updates: Partial<MaterialRequest>): Promise<MaterialRequest | undefined>;

  // Order operations
  getOrders(userId?: string, userType?: 'vendor' | 'supplier'): Promise<Order[]>;
  getOrderById(id: string): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: string, updates: Partial<Order>): Promise<Order | undefined>;

  // Quote operations
  getQuotes(requestId?: string, supplierId?: string): Promise<Quote[]>;
  createQuote(quote: InsertQuote): Promise<Quote>;
  updateQuote(id: string, updates: Partial<Quote>): Promise<Quote | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private materials: Map<string, Material> = new Map();
  private supplierInventory: Map<string, SupplierInventory> = new Map();
  private materialRequests: Map<string, MaterialRequest> = new Map();
  private orders: Map<string, Order> = new Map();
  private quotes: Map<string, Quote> = new Map();

  constructor() {
    this.initializeData();
  }

  private initializeData() {
    // Create some default materials
    const defaultMaterials = [
      { name: "Onions", category: "Vegetables", unit: "kg", description: "Fresh red onions" },
      { name: "Tomatoes", category: "Vegetables", unit: "kg", description: "Fresh ripe tomatoes" },
      { name: "Potatoes", category: "Vegetables", unit: "kg", description: "Fresh potatoes" },
      { name: "Cooking Oil", category: "Oils", unit: "liter", description: "Refined cooking oil" },
      { name: "Cumin Powder", category: "Spices", unit: "kg", description: "Ground cumin powder" },
      { name: "Wheat Flour", category: "Grains", unit: "kg", description: "All-purpose wheat flour" },
      { name: "Basmati Rice", category: "Grains", unit: "kg", description: "Premium basmati rice" },
      { name: "Green Chilies", category: "Vegetables", unit: "kg", description: "Fresh green chilies" },
    ];

    for (const material of defaultMaterials) {
      const id = randomUUID();
      this.materials.set(id, {
        id,
        ...material,
        createdAt: new Date(),
      });
    }
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async getUsersByType(userType: 'vendor' | 'supplier'): Promise<User[]> {
    return Array.from(this.users.values()).filter(user => user.userType === userType);
  }

  // Material operations
  async getAllMaterials(): Promise<Material[]> {
    return Array.from(this.materials.values());
  }

  async getMaterialById(id: string): Promise<Material | undefined> {
    return this.materials.get(id);
  }

  async createMaterial(material: InsertMaterial): Promise<Material> {
    const id = randomUUID();
    const newMaterial: Material = {
      ...material,
      id,
      createdAt: new Date(),
    };
    this.materials.set(id, newMaterial);
    return newMaterial;
  }

  async searchMaterials(query: string): Promise<Material[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.materials.values()).filter(material =>
      material.name.toLowerCase().includes(lowercaseQuery) ||
      material.category.toLowerCase().includes(lowercaseQuery) ||
      material.description?.toLowerCase().includes(lowercaseQuery)
    );
  }

  // Supplier inventory operations
  async getSupplierInventory(supplierId: string): Promise<SupplierInventory[]> {
    return Array.from(this.supplierInventory.values()).filter(item => item.supplierId === supplierId);
  }

  async getInventoryByMaterial(materialId: string): Promise<SupplierInventory[]> {
    return Array.from(this.supplierInventory.values()).filter(item => item.materialId === materialId && item.isActive);
  }

  async createInventoryItem(item: InsertSupplierInventory): Promise<SupplierInventory> {
    const id = randomUUID();
    const newItem: SupplierInventory = {
      ...item,
      id,
      updatedAt: new Date(),
    };
    this.supplierInventory.set(id, newItem);
    return newItem;
  }

  async updateInventoryItem(id: string, updates: Partial<SupplierInventory>): Promise<SupplierInventory | undefined> {
    const item = this.supplierInventory.get(id);
    if (!item) return undefined;
    
    const updatedItem = { ...item, ...updates, updatedAt: new Date() };
    this.supplierInventory.set(id, updatedItem);
    return updatedItem;
  }

  // Material request operations
  async getMaterialRequests(vendorId?: string): Promise<MaterialRequest[]> {
    const requests = Array.from(this.materialRequests.values());
    return vendorId ? requests.filter(req => req.vendorId === vendorId) : requests;
  }

  async getMaterialRequestById(id: string): Promise<MaterialRequest | undefined> {
    return this.materialRequests.get(id);
  }

  async createMaterialRequest(request: InsertMaterialRequest): Promise<MaterialRequest> {
    const id = randomUUID();
    const newRequest: MaterialRequest = {
      ...request,
      id,
      status: "pending",
      createdAt: new Date(),
    };
    this.materialRequests.set(id, newRequest);
    return newRequest;
  }

  async updateMaterialRequest(id: string, updates: Partial<MaterialRequest>): Promise<MaterialRequest | undefined> {
    const request = this.materialRequests.get(id);
    if (!request) return undefined;
    
    const updatedRequest = { ...request, ...updates };
    this.materialRequests.set(id, updatedRequest);
    return updatedRequest;
  }

  // Order operations
  async getOrders(userId?: string, userType?: 'vendor' | 'supplier'): Promise<Order[]> {
    const orders = Array.from(this.orders.values());
    if (!userId) return orders;
    
    return orders.filter(order => 
      userType === 'vendor' ? order.vendorId === userId : order.supplierId === userId
    );
  }

  async getOrderById(id: string): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const id = randomUUID();
    const newOrder: Order = {
      ...order,
      id,
      status: "pending",
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.orders.set(id, newOrder);
    return newOrder;
  }

  async updateOrder(id: string, updates: Partial<Order>): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    
    const updatedOrder = { ...order, ...updates, updatedAt: new Date() };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }

  // Quote operations
  async getQuotes(requestId?: string, supplierId?: string): Promise<Quote[]> {
    const quotes = Array.from(this.quotes.values());
    if (requestId) return quotes.filter(quote => quote.requestId === requestId);
    if (supplierId) return quotes.filter(quote => quote.supplierId === supplierId);
    return quotes;
  }

  async createQuote(quote: InsertQuote): Promise<Quote> {
    const id = randomUUID();
    const newQuote: Quote = {
      ...quote,
      id,
      status: "pending",
      createdAt: new Date(),
    };
    this.quotes.set(id, newQuote);
    return newQuote;
  }

  async updateQuote(id: string, updates: Partial<Quote>): Promise<Quote | undefined> {
    const quote = this.quotes.get(id);
    if (!quote) return undefined;
    
    const updatedQuote = { ...quote, ...updates };
    this.quotes.set(id, updatedQuote);
    return updatedQuote;
  }
}

export const storage = new MemStorage();
