# VendorConnect - Street Food Supply Chain Platform

## Overview

VendorConnect is a comprehensive supply chain management platform designed specifically for street food vendors and suppliers. It connects vendors who need raw materials with suppliers who have inventory, streamlining the ordering process and enabling real-time order tracking.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack React Query for server state management
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: JWT-based authentication with bcrypt for password hashing
- **Database Provider**: Neon Database (serverless PostgreSQL)

### Project Structure
The application follows a monorepo structure with clear separation:
- `/client` - React frontend application
- `/server` - Express.js backend API
- `/shared` - Shared TypeScript types and database schema

## Key Components

### Authentication System
- JWT-based authentication with secure token storage
- Role-based access control (vendor vs supplier)
- Protected routes and API endpoints
- User registration with business information

### Database Schema
The system uses five main entities:
- **Users**: Handles both vendors and suppliers with role-based differentiation
- **Materials**: Catalog of available raw materials with categories
- **Supplier Inventory**: Real-time inventory management with pricing
- **Material Requests**: Vendor requests for specific materials
- **Orders**: Complete order lifecycle management
- **Quotes**: Supplier responses to material requests

### User Roles
- **Vendors**: Browse suppliers, create material requests, place orders, track deliveries
- **Suppliers**: Manage inventory, respond to requests with quotes, fulfill orders

### Core Features
- Material search and discovery
- Real-time inventory management
- Quote and order management
- Order tracking with status updates
- Dashboard analytics for both user types

## Data Flow

1. **Vendor Journey**: Login → Browse/Search Materials → Create Requests → Receive Quotes → Place Orders → Track Delivery
2. **Supplier Journey**: Login → Manage Inventory → Respond to Requests → Fulfill Orders → Update Order Status
3. **Order Lifecycle**: Request → Quote → Order → Confirmation → Shipped → Delivered

## External Dependencies

### Database & Infrastructure
- **Neon Database**: Serverless PostgreSQL hosting
- **Drizzle ORM**: Type-safe database queries and migrations

### Frontend Libraries
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first styling
- **TanStack React Query**: Server state management
- **React Hook Form**: Form handling and validation

### Backend Libraries
- **bcryptjs**: Password hashing
- **jsonwebtoken**: JWT token management
- **connect-pg-simple**: Session management

## Deployment Strategy

### Development Environment
- Vite dev server for frontend with HMR
- tsx for TypeScript execution in development
- Replit-specific plugins for development environment integration

### Production Build
- Frontend: Vite build to static assets
- Backend: esbuild bundling for Node.js deployment
- Database migrations via Drizzle Kit

### Environment Configuration
- `DATABASE_URL`: PostgreSQL connection string
- `JWT_SECRET`: Secret key for JWT signing
- `NODE_ENV`: Environment specification (development/production)

## Recent Changes

### Latest Updates (January 2025)
- ✅ Fixed button text visibility issues on landing page ("Join as Supplier" and "Watch Demo" buttons)
- ✅ Implemented rich blue color scheme as requested by user
- ✅ Enhanced button contrast and styling for better UX
- ✅ Created comprehensive README.md and deployment documentation
- ✅ Organized project structure for ready-to-deploy package
- ✅ Added environment variables template (.env.example)
- ✅ Created deployment guide with multiple hosting options

### Project Status
The application is **production-ready** and organized for deployment:
- Complete B2B marketplace functionality connecting street food vendors with suppliers
- Modern UI with rich blue theme and professional design
- Dual authentication system (vendors/suppliers) with JWT
- Real-time order tracking and inventory management
- Mobile-responsive design with fixed button visibility
- Comprehensive documentation for easy deployment

The application is designed to be deployed on platforms supporting Node.js with PostgreSQL database connectivity, with specific optimizations for Replit deployment. The entire project is ready to be zipped and deployed immediately.