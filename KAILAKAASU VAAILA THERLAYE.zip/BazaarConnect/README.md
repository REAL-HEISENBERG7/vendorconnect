# VendorConnect - Street Food Supply Chain Platform

A comprehensive B2B platform connecting Indian street food vendors with raw material suppliers, featuring real-time order tracking, inventory management, and modern UI design.

## 🚀 Features

### For Vendors
- **Material Discovery**: Search and browse raw materials from verified suppliers
- **Smart Requests**: Create material requests with specifications
- **Order Management**: Track orders from placement to delivery
- **Supplier Network**: Connect with reliable, pre-verified suppliers
- **Dashboard Analytics**: Monitor spending patterns and order history

### For Suppliers
- **Inventory Management**: Real-time stock tracking and pricing
- **Quote System**: Respond to vendor requests with competitive quotes
- **Order Fulfillment**: Process and track order deliveries
- **Business Analytics**: Insights into sales performance and customer patterns

## 🛠️ Tech Stack

### Frontend
- **React 18** with TypeScript
- **Tailwind CSS** for styling
- **shadcn/ui** component library
- **Wouter** for routing
- **TanStack React Query** for state management
- **React Hook Form** with Zod validation

### Backend
- **Node.js** with Express and TypeScript
- **PostgreSQL** with Drizzle ORM
- **JWT Authentication** with bcrypt
- **Real-time WebSocket** support
- **Neon Database** (serverless PostgreSQL)

## 📁 Project Structure

```
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/          # Page components
│   │   ├── hooks/          # Custom React hooks
│   │   ├── lib/            # Utility functions
│   │   └── App.tsx         # Main app component
│   └── index.html
├── server/                 # Backend Express API
│   ├── index.ts           # Server entry point
│   ├── routes.ts          # API routes
│   ├── storage.ts         # Data storage layer
│   ├── db.ts              # Database configuration
│   └── vite.ts            # Development server
├── shared/                # Shared TypeScript types
│   └── schema.ts          # Database schema and types
├── package.json           # Dependencies and scripts
├── vite.config.ts         # Vite configuration
├── tailwind.config.ts     # Tailwind CSS configuration
└── tsconfig.json          # TypeScript configuration
```

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- PostgreSQL database
- npm or yarn

### Installation

1. **Clone and install dependencies**
   ```bash
   npm install
   ```

2. **Set up environment variables**
   Create a `.env` file in the root directory:
   ```env
   DATABASE_URL=your_postgresql_connection_string
   JWT_SECRET=your_jwt_secret_key
   NODE_ENV=development
   ```

3. **Set up the database**
   ```bash
   # Push schema to database
   npm run db:push
   ```

4. **Start the development server**
   ```bash
   npm run dev
   ```

   The application will be available at `http://localhost:5000`

### Production Build

1. **Build the application**
   ```bash
   npm run build
   ```

2. **Start production server**
   ```bash
   npm start
   ```

## 📱 User Roles & Access

### Vendor Dashboard (`/vendor/dashboard`)
- Material search and discovery
- Create and manage material requests
- View quotes from suppliers
- Place and track orders
- Business analytics and insights

### Supplier Dashboard (`/supplier/dashboard`)
- Inventory management
- View and respond to material requests
- Order processing and fulfillment
- Sales analytics and reporting

## 🔧 Development Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run db:push` - Push schema changes to database
- `npm run db:studio` - Open Drizzle Studio (database GUI)

## 🎨 Design System

The platform uses a modern design system with:
- **Rich blue gradient** primary theme
- **Responsive design** for mobile and desktop
- **Glassmorphism effects** for modern UI elements
- **Consistent spacing** and typography
- **Accessible components** with proper contrast ratios

## 🔐 Authentication

- JWT-based authentication with secure token storage
- Role-based access control (vendor vs supplier)
- Protected routes and API endpoints
- Session management with PostgreSQL storage

## 📊 Database Schema

### Core Entities
- **Users**: Both vendors and suppliers with role differentiation
- **Materials**: Catalog of available raw materials with categories
- **Supplier Inventory**: Real-time inventory with pricing
- **Material Requests**: Vendor requests for specific materials
- **Orders**: Complete order lifecycle management
- **Quotes**: Supplier responses to material requests

## 🚀 Deployment

### Platform Support
- **Replit**: Optimized for Replit deployment
- **Vercel**: Frontend deployment ready
- **Railway/Render**: Backend deployment ready
- **Neon/Supabase**: Database hosting compatible

### Environment Configuration
Ensure these environment variables are set in production:
- `DATABASE_URL`: PostgreSQL connection string
- `JWT_SECRET`: Secret key for JWT signing
- `NODE_ENV`: Set to "production"

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

For issues and questions:
1. Check the documentation above
2. Review the codebase structure
3. Ensure all environment variables are properly set
4. Verify database connectivity

---

Built with ❤️ for the Indian street food community