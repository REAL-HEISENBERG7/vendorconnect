import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { Store, Truck, Menu, X } from "lucide-react";

export default function Navbar() {
  const { user, logout } = useAuth();
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <nav className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link href="/" className="flex-shrink-0">
              <h1 className="text-2xl font-bold text-primary" data-testid="logo">VendorConnect</h1>
            </Link>
            
            {user && (
              <div className="hidden md:block ml-10">
                <div className="flex items-baseline space-x-4">
                  <Link 
                    href="/" 
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      isActive('/') 
                        ? 'text-primary bg-primary/10' 
                        : 'text-gray-600 hover:text-primary'
                    }`}
                    data-testid="nav-dashboard"
                  >
                    Dashboard
                  </Link>
                  
                  {user.userType === 'vendor' ? (
                    <>
                      <Link 
                        href="/search" 
                        className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                          isActive('/search') 
                            ? 'text-primary bg-primary/10' 
                            : 'text-gray-600 hover:text-primary'
                        }`}
                        data-testid="nav-search"
                      >
                        Find Suppliers
                      </Link>
                      <Link 
                        href="/orders" 
                        className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                          isActive('/orders') 
                            ? 'text-primary bg-primary/10' 
                            : 'text-gray-600 hover:text-primary'
                        }`}
                        data-testid="nav-orders"
                      >
                        My Orders
                      </Link>
                    </>
                  ) : (
                    <>
                      <Link 
                        href="/inventory" 
                        className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                          isActive('/inventory') 
                            ? 'text-primary bg-primary/10' 
                            : 'text-gray-600 hover:text-primary'
                        }`}
                        data-testid="nav-inventory"
                      >
                        Inventory
                      </Link>
                      <Link 
                        href="/orders" 
                        className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                          isActive('/orders') 
                            ? 'text-primary bg-primary/10' 
                            : 'text-gray-600 hover:text-primary'
                        }`}
                        data-testid="nav-orders"
                      >
                        Orders
                      </Link>
                    </>
                  )}
                </div>
              </div>
            )}
          </div>

          <div className="hidden md:block">
            {user ? (
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  {user.userType === 'vendor' ? <Store className="h-4 w-4" /> : <Truck className="h-4 w-4" />}
                  <span data-testid="user-business-name">{user.businessName || user.username}</span>
                </div>
                <Button 
                  variant="outline" 
                  onClick={logout}
                  data-testid="button-logout"
                >
                  Logout
                </Button>
              </div>
            ) : (
              <div className="flex items-center space-x-3">
                <Link href="/login">
                  <Button variant="outline" data-testid="button-login">Login</Button>
                </Link>
                <Link href="/signup">
                  <Button data-testid="button-signup">Sign Up</Button>
                </Link>
              </div>
            )}
          </div>

          <div className="md:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              data-testid="button-mobile-menu"
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden py-4 border-t">
            {user ? (
              <div className="space-y-3">
                <div className="flex items-center space-x-2 text-sm text-gray-600 px-3">
                  {user.userType === 'vendor' ? <Store className="h-4 w-4" /> : <Truck className="h-4 w-4" />}
                  <span>{user.businessName || user.username}</span>
                </div>
                
                <Link href="/" className="block px-3 py-2 text-gray-600 hover:text-primary">
                  Dashboard
                </Link>
                
                {user.userType === 'vendor' ? (
                  <>
                    <Link href="/search" className="block px-3 py-2 text-gray-600 hover:text-primary">
                      Find Suppliers
                    </Link>
                    <Link href="/orders" className="block px-3 py-2 text-gray-600 hover:text-primary">
                      My Orders
                    </Link>
                  </>
                ) : (
                  <>
                    <Link href="/inventory" className="block px-3 py-2 text-gray-600 hover:text-primary">
                      Inventory
                    </Link>
                    <Link href="/orders" className="block px-3 py-2 text-gray-600 hover:text-primary">
                      Orders
                    </Link>
                  </>
                )}
                
                <Button 
                  variant="outline" 
                  onClick={logout}
                  className="mx-3"
                >
                  Logout
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                <Link href="/login" className="block px-3 py-2 text-gray-600 hover:text-primary">
                  Login
                </Link>
                <Link href="/signup" className="block px-3 py-2 text-gray-600 hover:text-primary">
                  Sign Up
                </Link>
              </div>
            )}
          </div>
        )}
      </div>
    </nav>
  );
}
