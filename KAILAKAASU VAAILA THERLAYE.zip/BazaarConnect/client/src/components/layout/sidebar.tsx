import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { 
  Store, 
  Search, 
  ShoppingCart, 
  Package, 
  List, 
  Home,
  Truck,
  LogOut
} from "lucide-react";

interface SidebarProps {
  className?: string;
}

export default function Sidebar({ className }: SidebarProps) {
  const { user, logout } = useAuth();
  const [location] = useLocation();

  const vendorNavigation = [
    {
      name: "Dashboard",
      href: "/",
      icon: Home,
    },
    {
      name: "Find Suppliers",
      href: "/search",
      icon: Search,
    },
    {
      name: "My Orders",
      href: "/orders",
      icon: ShoppingCart,
    },
  ];

  const supplierNavigation = [
    {
      name: "Dashboard",
      href: "/",
      icon: Home,
    },
    {
      name: "Inventory",
      href: "/inventory",
      icon: Package,
    },
    {
      name: "Orders",
      href: "/orders",
      icon: List,
    },
  ];

  const navigation = user?.userType === 'vendor' ? vendorNavigation : supplierNavigation;

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <div className={cn("flex flex-col w-64 bg-white border-r border-gray-200", className)}>
      {/* Logo */}
      <div className="flex items-center px-6 py-4 border-b border-gray-200">
        <div className="flex items-center space-x-2">
          {user?.userType === 'vendor' ? (
            <Store className="h-6 w-6 text-primary" />
          ) : (
            <Truck className="h-6 w-6 text-primary" />
          )}
          <h1 className="text-xl font-bold text-gray-900">VendorConnect</h1>
        </div>
      </div>

      {/* User Info */}
      <div className="px-6 py-4 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="bg-primary/10 rounded-full p-2">
            {user?.userType === 'vendor' ? (
              <Store className="h-5 w-5 text-primary" />
            ) : (
              <Truck className="h-5 w-5 text-primary" />
            )}
          </div>
          <div>
            <p className="font-medium text-gray-900">
              {user?.businessName || user?.username}
            </p>
            <p className="text-sm text-gray-500 capitalize">
              {user?.userType}
            </p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-4 py-4 space-y-2">
        {navigation.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.name} href={item.href}>
              <Button
                variant={isActive(item.href) ? "secondary" : "ghost"}
                className={cn(
                  "w-full justify-start",
                  isActive(item.href) && "bg-primary/10 text-primary hover:bg-primary/10"
                )}
                data-testid={`nav-${item.href.replace('/', '') || 'dashboard'}`}
              >
                <Icon className="mr-3 h-4 w-4" />
                {item.name}
              </Button>
            </Link>
          );
        })}
      </nav>

      {/* Logout */}
      <div className="p-4 border-t border-gray-200">
        <Button
          variant="ghost"
          className="w-full justify-start text-gray-600 hover:text-gray-900"
          onClick={logout}
          data-testid="button-logout"
        >
          <LogOut className="mr-3 h-4 w-4" />
          Logout
        </Button>
      </div>
    </div>
  );
}
