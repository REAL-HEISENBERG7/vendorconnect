import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  CheckCircle, 
  Package, 
  Truck, 
  MapPin, 
  Clock,
  AlertCircle,
  Phone,
  User,
  IndianRupee,
  Calendar
} from "lucide-react";

interface OrderTrackingProps {
  order: any;
}

export default function OrderTracking({ order }: OrderTrackingProps) {
  const getTrackingSteps = () => {
    const steps = [
      {
        id: 'confirmed',
        title: 'Order Confirmed',
        description: 'Your order has been confirmed by the supplier',
        icon: CheckCircle,
        completed: ['confirmed', 'shipped', 'delivered'].includes(order.status),
        active: order.status === 'confirmed',
      },
      {
        id: 'packed',
        title: 'Order Packed',
        description: 'Your items have been packed and ready for pickup',
        icon: Package,
        completed: ['shipped', 'delivered'].includes(order.status),
        active: false,
      },
      {
        id: 'shipped',
        title: 'Out for Delivery',
        description: 'Your order is on the way to your location',
        icon: Truck,
        completed: order.status === 'delivered',
        active: order.status === 'shipped',
      },
      {
        id: 'delivered',
        title: 'Delivered',
        description: 'Order has been delivered to your location',
        icon: MapPin,
        completed: order.status === 'delivered',
        active: false,
      },
    ];

    if (order.status === 'pending') {
      return [
        {
          id: 'pending',
          title: 'Order Placed',
          description: 'Waiting for supplier confirmation',
          icon: Clock,
          completed: true,
          active: true,
        },
        ...steps.map(step => ({ ...step, completed: false, active: false })),
      ];
    }

    if (order.status === 'cancelled') {
      return [
        {
          id: 'cancelled',
          title: 'Order Cancelled',
          description: 'This order has been cancelled',
          icon: AlertCircle,
          completed: true,
          active: true,
          error: true,
        },
      ];
    }

    return steps;
  };

  const steps = getTrackingSteps();
  const completedSteps = steps.filter(step => step.completed).length;
  const progressPercentage = order.status === 'cancelled' ? 0 : (completedSteps / steps.length) * 100;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'delivered': return 'bg-secondary text-white';
      case 'shipped': return 'bg-warning text-white';
      case 'confirmed': return 'bg-accent text-white';
      case 'pending': return 'bg-gray-500 text-white';
      case 'cancelled': return 'bg-destructive text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  return (
    <div className="space-y-6">
      {/* Order Header */}
      <Card className="shadow-xl border border-gray-100 overflow-hidden">
        <div className="hero-gradient text-white p-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
            <div>
              <h2 className="text-2xl font-semibold mb-2">
                Order #{order.id.slice(-8).toUpperCase()}
              </h2>
              <p className="opacity-90">
                {order.material?.name} - {order.quantity}{order.material?.unit} from {order.supplier?.businessName}
              </p>
            </div>
            <div className="mt-4 md:mt-0 text-right">
              <div className="flex items-center text-2xl font-semibold mb-1">
                <IndianRupee className="h-6 w-6" />
                <span>{parseFloat(order.totalAmount).toFixed(2)}</span>
              </div>
              <p className="text-sm opacity-90">
                {order.estimatedDelivery 
                  ? `Expected delivery: ${new Date(order.estimatedDelivery).toLocaleDateString()}`
                  : 'Delivery time pending'
                }
              </p>
            </div>
          </div>
        </div>

        <CardContent className="p-8">
          {/* Progress Indicator */}
          <div className="mb-8">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-700">Order Progress</span>
              <Badge className={getStatusColor(order.status)}>
                {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
              </Badge>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className={`h-2 rounded-full transition-all duration-500 ${
                  order.status === 'cancelled' ? 'bg-destructive' : 'bg-secondary'
                }`}
                style={{ width: `${progressPercentage}%` }}
              ></div>
            </div>
          </div>

          {/* Tracking Steps */}
          <div className="relative">
            {/* Progress Line */}
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gray-200"></div>
            {order.status !== 'cancelled' && (
              <div 
                className="absolute left-8 top-0 w-0.5 bg-secondary transition-all duration-1000"
                style={{ height: `${progressPercentage}%` }}
              ></div>
            )}

            {/* Steps */}
            <div className="space-y-8">
              {steps.map((step, index) => {
                const Icon = step.icon;
                return (
                  <div key={step.id} className="flex items-center relative">
                    <div 
                      className={`rounded-full w-16 h-16 flex items-center justify-center z-10 shadow-lg ${
                        step.error ? 'bg-destructive text-white' :
                        step.completed ? 'bg-secondary text-white' :
                        step.active ? 'bg-secondary text-white animate-pulse' :
                        'bg-gray-200 text-gray-400'
                      }`}
                    >
                      <Icon className="h-6 w-6" />
                    </div>
                    <div className="ml-6">
                      <h3 className={`text-lg font-semibold ${
                        step.error ? 'text-destructive' :
                        step.completed || step.active ? 'text-gray-900' : 'text-gray-400'
                      }`}>
                        {step.title}
                      </h3>
                      <p className={`${
                        step.error ? 'text-destructive' :
                        step.completed || step.active ? 'text-gray-600' : 'text-gray-400'
                      }`}>
                        {step.description}
                      </p>
                      {step.active && (
                        <p className="text-sm text-gray-500 mt-1">
                          {new Date().toLocaleString()}
                        </p>
                      )}
                      {step.completed && !step.active && (
                        <p className="text-sm text-gray-500 mt-1">
                          Completed
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Order Details */}
          <div className="mt-8 bg-gray-50 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Order Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Vendor</p>
                  <div className="flex items-center space-x-2">
                    <User className="h-4 w-4 text-gray-400" />
                    <p className="font-medium text-gray-900">
                      {order.vendor?.businessName || "Unknown Vendor"}
                    </p>
                  </div>
                </div>
                
                <div>
                  <p className="text-sm text-gray-600 mb-1">Contact</p>
                  <div className="flex items-center space-x-2">
                    <Phone className="h-4 w-4 text-gray-400" />
                    <p className="font-medium text-gray-900">
                      {order.vendor?.contactNumber || "Not provided"}
                    </p>
                  </div>
                </div>
                
                <div>
                  <p className="text-sm text-gray-600 mb-1">Order Date</p>
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4 text-gray-400" />
                    <p className="font-medium text-gray-900">
                      {new Date(order.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Supplier</p>
                  <div className="flex items-center space-x-2">
                    <Truck className="h-4 w-4 text-gray-400" />
                    <p className="font-medium text-gray-900">
                      {order.supplier?.businessName || "Unknown Supplier"}
                    </p>
                  </div>
                </div>
                
                <div>
                  <p className="text-sm text-gray-600 mb-1">Delivery Address</p>
                  <div className="flex items-start space-x-2">
                    <MapPin className="h-4 w-4 text-gray-400 mt-0.5" />
                    <p className="font-medium text-gray-900">
                      {order.deliveryAddress || "Address not provided"}
                    </p>
                  </div>
                </div>
                
                <div>
                  <p className="text-sm text-gray-600 mb-1">Total Amount</p>
                  <div className="flex items-center space-x-2">
                    <IndianRupee className="h-4 w-4 text-gray-400" />
                    <p className="font-medium text-gray-900 text-lg">
                      {parseFloat(order.totalAmount).toFixed(2)}
                    </p>
                    <span className="text-sm text-gray-500">
                      (₹{parseFloat(order.pricePerUnit).toFixed(2)} per {order.material?.unit})
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
