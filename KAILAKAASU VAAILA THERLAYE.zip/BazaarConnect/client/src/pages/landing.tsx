import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Navbar from "@/components/layout/navbar";
import { 
  Store, 
  Truck, 
  Search, 
  Handshake, 
  FastForward, 
  ChartBar, 
  Smartphone, 
  Lock,
  Users,
  TrendingUp,
  CheckCircle,
  Box,
  Clock,
  MapPin
} from "lucide-react";

export default function Landing() {
  const [activeTab, setActiveTab] = useState<'vendor' | 'supplier'>('vendor');

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      {/* Hero Section */}
      <section className="hero-gradient text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl lg:text-6xl font-bold mb-6 leading-tight">
                Streamline Your <span className="text-yellow-300">Street Food</span> Supply Chain
              </h1>
              <p className="text-xl mb-8 opacity-90">
                Connect vendors with reliable suppliers, track orders in real-time, and optimize your raw material sourcing with our comprehensive platform.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/signup">
                  <Button 
                    className="bg-white text-blue-600 hover:bg-gray-100 hover:text-blue-700 px-8 py-4 text-lg h-auto font-semibold"
                    data-testid="button-join-vendor"
                  >
                    <Store className="mr-2 h-5 w-5" />
                    Join as Vendor
                  </Button>
                </Link>
                <Link href="/signup">
                  <Button 
                    variant="outline" 
                    className="border-2 border-white bg-transparent text-white hover:bg-white hover:text-blue-600 px-8 py-4 text-lg h-auto font-semibold"
                    data-testid="button-join-supplier"
                  >
                    <Truck className="mr-2 h-5 w-5" />
                    Join as Supplier
                  </Button>
                </Link>
              </div>
            </div>
            
            <div className="hidden lg:block">
              <div className="relative">
                <div className="glass-card rounded-2xl p-8 transform rotate-3 hover:rotate-0 transition-transform duration-300 float-animation">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white/20 rounded-lg p-4 text-center">
                      <Store className="h-8 w-8 mx-auto mb-2" />
                      <p className="font-semibold">500+ Vendors</p>
                    </div>
                    <div className="bg-white/20 rounded-lg p-4 text-center">
                      <Truck className="h-8 w-8 mx-auto mb-2" />
                      <p className="font-semibold">200+ Suppliers</p>
                    </div>
                    <div className="bg-white/20 rounded-lg p-4 text-center">
                      <Clock className="h-8 w-8 mx-auto mb-2" />
                      <p className="font-semibold">Real-time Tracking</p>
                    </div>
                    <div className="bg-white/20 rounded-lg p-4 text-center">
                      <TrendingUp className="h-8 w-8 mx-auto mb-2" />
                      <p className="font-semibold">Analytics</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Why Choose VendorConnect?</h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              Revolutionizing the way street food vendors source raw materials with modern technology and reliable partnerships.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-8">
                <div className="bg-primary/10 rounded-full w-16 h-16 flex items-center justify-center mb-6">
                  <Search className="text-primary h-8 w-8" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Smart Search & Discovery</h3>
                <p className="text-gray-600">
                  Find the exact raw materials you need with advanced filtering and location-based supplier recommendations.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-8">
                <div className="bg-secondary/10 rounded-full w-16 h-16 flex items-center justify-center mb-6">
                  <Handshake className="text-secondary h-8 w-8" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Verified Suppliers</h3>
                <p className="text-gray-600">
                  Connect with pre-verified, reliable suppliers who understand the street food business requirements.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-8">
                <div className="bg-accent/10 rounded-full w-16 h-16 flex items-center justify-center mb-6">
                  <FastForward className="text-accent h-8 w-8" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Real-time Tracking</h3>
                <p className="text-gray-600">
                  Track your orders from placement to delivery with live updates and notifications.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-8">
                <div className="bg-warning/10 rounded-full w-16 h-16 flex items-center justify-center mb-6">
                  <ChartBar className="text-warning h-8 w-8" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Business Analytics</h3>
                <p className="text-gray-600">
                  Get insights into your spending patterns, supplier performance, and optimize your inventory management.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-8">
                <div className="bg-red-500/10 rounded-full w-16 h-16 flex items-center justify-center mb-6">
                  <Smartphone className="text-red-500 h-8 w-8" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Mobile-First Design</h3>
                <p className="text-gray-600">
                  Manage your business on-the-go with our responsive mobile interface designed for busy vendors.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-8">
                <div className="bg-purple-500/10 rounded-full w-16 h-16 flex items-center justify-center mb-6">
                  <Lock className="text-purple-500 h-8 w-8" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Secure Payments</h3>
                <p className="text-gray-600">
                  Safe and secure payment processing with multiple payment options and transaction history.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Dashboard Preview Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Powerful Dashboards for Every User</h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              Intuitive interfaces designed specifically for vendors and suppliers to manage their business efficiently.
            </p>
          </div>

          {/* Dashboard Tabs */}
          <div className="flex justify-center mb-12">
            <div className="bg-white rounded-lg p-1 shadow-md">
              <Button
                onClick={() => setActiveTab('vendor')}
                variant={activeTab === 'vendor' ? 'default' : 'ghost'}
                className="px-8 py-3"
                data-testid="tab-vendor-dashboard"
              >
                <Store className="mr-2 h-4 w-4" />
                Vendor Dashboard
              </Button>
              <Button
                onClick={() => setActiveTab('supplier')}
                variant={activeTab === 'supplier' ? 'default' : 'ghost'}
                className="px-8 py-3"
                data-testid="tab-supplier-dashboard"
              >
                <Truck className="mr-2 h-4 w-4" />
                Supplier Dashboard
              </Button>
            </div>
          </div>

          {/* Dashboard Content */}
          <Card className="shadow-xl">
            <CardContent className="p-8">
              {activeTab === 'vendor' ? (
                <div>
                  <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8">
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900 mb-2">Welcome back, Raj Kumar!</h3>
                      <p className="text-gray-600">Manage your raw material requirements and track orders</p>
                    </div>
                    <Button className="mt-4 lg:mt-0" data-testid="button-new-request">
                      <Box className="mr-2 h-4 w-4" />
                      New Request
                    </Button>
                  </div>

                  {/* Stats Cards */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <div className="bg-gradient-to-r from-primary to-orange-600 text-white rounded-xl p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-orange-100 text-sm font-medium">Active Orders</p>
                          <p className="text-3xl font-bold">12</p>
                        </div>
                        <Box className="h-8 w-8 text-orange-200" />
                      </div>
                    </div>
                    
                    <div className="bg-gradient-to-r from-secondary to-green-600 text-white rounded-xl p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-green-100 text-sm font-medium">This Month</p>
                          <p className="text-3xl font-bold">₹45,230</p>
                        </div>
                        <TrendingUp className="h-8 w-8 text-green-200" />
                      </div>
                    </div>
                    
                    <div className="bg-gradient-to-r from-accent to-blue-600 text-white rounded-xl p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-blue-100 text-sm font-medium">Suppliers</p>
                          <p className="text-3xl font-bold">8</p>
                        </div>
                        <Truck className="h-8 w-8 text-blue-200" />
                      </div>
                    </div>
                    
                    <div className="bg-gradient-to-r from-warning to-yellow-600 text-white rounded-xl p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-yellow-100 text-sm font-medium">Avg. Delivery</p>
                          <p className="text-3xl font-bold">2.3 days</p>
                        </div>
                        <Clock className="h-8 w-8 text-yellow-200" />
                      </div>
                    </div>
                  </div>

                  {/* Sample Orders */}
                  <div className="bg-gray-50 rounded-xl p-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-4">Recent Orders</h4>
                    <div className="space-y-4">
                      <div className="bg-white rounded-lg p-4 border-l-4 border-secondary">
                        <div className="flex justify-between items-start mb-2">
                          <h5 className="font-medium text-gray-900">Fresh Onions - 10kg</h5>
                          <span className="bg-secondary text-white text-xs px-2 py-1 rounded-full">Delivered</span>
                        </div>
                        <p className="text-sm text-gray-600">Ram Suppliers</p>
                        <p className="text-sm text-gray-500">Delivered 2 hours ago</p>
                      </div>
                      
                      <div className="bg-white rounded-lg p-4 border-l-4 border-warning">
                        <div className="flex justify-between items-start mb-2">
                          <h5 className="font-medium text-gray-900">Tomatoes - 5kg</h5>
                          <span className="bg-warning text-white text-xs px-2 py-1 rounded-full">In Transit</span>
                        </div>
                        <p className="text-sm text-gray-600">Fresh Farm Co.</p>
                        <p className="text-sm text-gray-500">Expected in 3 hours</p>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div>
                  <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8">
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900 mb-2">Welcome back, Fresh Farm Co.!</h3>
                      <p className="text-gray-600">Manage your inventory and fulfill vendor orders</p>
                    </div>
                    <Button className="mt-4 lg:mt-0 bg-secondary hover:bg-green-600" data-testid="button-add-product">
                      <Box className="mr-2 h-4 w-4" />
                      Add Product
                    </Button>
                  </div>

                  {/* Stats Cards */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <div className="bg-gradient-to-r from-secondary to-green-600 text-white rounded-xl p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-green-100 text-sm font-medium">Active Orders</p>
                          <p className="text-3xl font-bold">18</p>
                        </div>
                        <Box className="h-8 w-8 text-green-200" />
                      </div>
                    </div>
                    
                    <div className="bg-gradient-to-r from-primary to-orange-600 text-white rounded-xl p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-orange-100 text-sm font-medium">Monthly Revenue</p>
                          <p className="text-3xl font-bold">₹1,25,480</p>
                        </div>
                        <TrendingUp className="h-8 w-8 text-orange-200" />
                      </div>
                    </div>
                    
                    <div className="bg-gradient-to-r from-accent to-blue-600 text-white rounded-xl p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-blue-100 text-sm font-medium">Products Listed</p>
                          <p className="text-3xl font-bold">24</p>
                        </div>
                        <Box className="h-8 w-8 text-blue-200" />
                      </div>
                    </div>
                    
                    <div className="bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-xl p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-purple-100 text-sm font-medium">Rating</p>
                          <p className="text-3xl font-bold">4.8★</p>
                        </div>
                        <Users className="h-8 w-8 text-purple-200" />
                      </div>
                    </div>
                  </div>

                  {/* Sample Pending Orders */}
                  <div className="bg-gray-50 rounded-xl p-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-4">Pending Orders</h4>
                    <div className="space-y-4">
                      <div className="bg-white rounded-lg p-4 border-l-4 border-warning">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h5 className="font-medium text-gray-900">Fresh Onions - 10kg</h5>
                            <p className="text-sm text-gray-600">Raj's Chaat Corner</p>
                          </div>
                          <span className="text-lg font-semibold text-gray-900">₹450</span>
                        </div>
                        <div className="flex justify-between items-center mt-3">
                          <p className="text-sm text-gray-500">2 hours ago</p>
                          <div className="flex space-x-2">
                            <Button size="sm" className="bg-secondary hover:bg-green-600">Accept</Button>
                            <Button size="sm" variant="destructive">Decline</Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Order Tracking Demo */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Real-time Order Tracking</h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              Track your orders from placement to delivery with live updates and notifications.
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <Card className="shadow-xl border border-gray-100 overflow-hidden">
              <div className="hero-gradient text-white p-6">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Order #VC2024001</h3>
                    <p className="opacity-90">Fresh Onions - 10kg from Ram Suppliers</p>
                  </div>
                  <div className="mt-4 md:mt-0 text-right">
                    <p className="text-lg font-semibold">₹450</p>
                    <p className="text-sm opacity-90">Estimated delivery: 2 hours</p>
                  </div>
                </div>
              </div>

              <CardContent className="p-8">
                <div className="relative">
                  <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gray-200"></div>
                  <div className="absolute left-8 top-0 w-0.5 bg-secondary h-3/4"></div>

                  <div className="space-y-8">
                    <div className="flex items-center relative">
                      <div className="bg-secondary text-white rounded-full w-16 h-16 flex items-center justify-center z-10 shadow-lg">
                        <CheckCircle className="h-6 w-6" />
                      </div>
                      <div className="ml-6">
                        <h4 className="text-lg font-semibold text-gray-900">Order Confirmed</h4>
                        <p className="text-gray-600">Your order has been confirmed by the supplier</p>
                        <p className="text-sm text-gray-500 mt-1">Today at 10:30 AM</p>
                      </div>
                    </div>

                    <div className="flex items-center relative">
                      <div className="bg-secondary text-white rounded-full w-16 h-16 flex items-center justify-center z-10 shadow-lg">
                        <Box className="h-6 w-6" />
                      </div>
                      <div className="ml-6">
                        <h4 className="text-lg font-semibold text-gray-900">Order Packed</h4>
                        <p className="text-gray-600">Your items have been packed and ready for pickup</p>
                        <p className="text-sm text-gray-500 mt-1">Today at 11:15 AM</p>
                      </div>
                    </div>

                    <div className="flex items-center relative">
                      <div className="bg-secondary text-white rounded-full w-16 h-16 flex items-center justify-center z-10 shadow-lg animate-pulse">
                        <Truck className="h-6 w-6" />
                      </div>
                      <div className="ml-6">
                        <h4 className="text-lg font-semibold text-gray-900">Out for Delivery</h4>
                        <p className="text-gray-600">Your order is on the way to your location</p>
                        <p className="text-sm text-gray-500 mt-1">Today at 12:00 PM</p>
                        <div className="mt-2">
                          <span className="bg-primary text-white text-xs px-2 py-1 rounded-full">In Transit</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center relative">
                      <div className="bg-gray-200 text-gray-400 rounded-full w-16 h-16 flex items-center justify-center z-10">
                        <MapPin className="h-6 w-6" />
                      </div>
                      <div className="ml-6">
                        <h4 className="text-lg font-semibold text-gray-400">Delivered</h4>
                        <p className="text-gray-400">Order will be delivered to your location</p>
                        <p className="text-sm text-gray-400 mt-1">Expected by 2:00 PM</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 hero-gradient text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">Ready to Transform Your Business?</h2>
          <p className="text-xl mb-10 opacity-90 max-w-2xl mx-auto">
            Join thousands of vendors and suppliers who are already streamlining their operations with VendorConnect.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link href="/signup">
              <Button 
                className="bg-white text-blue-600 hover:bg-gray-100 hover:text-blue-700 px-8 py-4 text-lg h-auto min-w-[200px] font-semibold"
                data-testid="button-get-started"
              >
                <TrendingUp className="mr-2 h-5 w-5" />
                Get Started Now
              </Button>
            </Link>
            <Button 
              variant="outline" 
              className="border-2 border-white bg-transparent text-white hover:bg-white hover:text-blue-600 px-8 py-4 text-lg h-auto min-w-[200px] font-semibold"
              data-testid="button-watch-demo"
            >
              <Box className="mr-2 h-5 w-5" />
              Watch Demo
            </Button>
          </div>
          
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="glass-card rounded-xl p-6">
              <Users className="h-12 w-12 mx-auto mb-4" />
              <h3 className="text-2xl font-bold mb-2">500+</h3>
              <p className="opacity-90">Active Vendors</p>
            </div>
            <div className="glass-card rounded-xl p-6">
              <Truck className="h-12 w-12 mx-auto mb-4" />
              <h3 className="text-2xl font-bold mb-2">200+</h3>
              <p className="opacity-90">Verified Suppliers</p>
            </div>
            <div className="glass-card rounded-xl p-6">
              <TrendingUp className="h-12 w-12 mx-auto mb-4" />
              <h3 className="text-2xl font-bold mb-2">10,000+</h3>
              <p className="opacity-90">Orders Completed</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="lg:col-span-2">
              <h3 className="text-2xl font-bold text-primary mb-4">VendorConnect</h3>
              <p className="text-gray-300 mb-6 max-w-md">
                Revolutionizing raw material sourcing for Indian street food vendors through technology and reliable partnerships.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Company</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-300 hover:text-primary transition-colors">About Us</a></li>
                <li><a href="#" className="text-gray-300 hover:text-primary transition-colors">Careers</a></li>
                <li><a href="#" className="text-gray-300 hover:text-primary transition-colors">Press</a></li>
                <li><a href="#" className="text-gray-300 hover:text-primary transition-colors">Blog</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Support</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-300 hover:text-primary transition-colors">Help Center</a></li>
                <li><a href="#" className="text-gray-300 hover:text-primary transition-colors">Contact Us</a></li>
                <li><a href="#" className="text-gray-300 hover:text-primary transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="text-gray-300 hover:text-primary transition-colors">Terms of Service</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-12 pt-8 text-center">
            <p className="text-gray-400">&copy; 2024 VendorConnect. All rights reserved. Built for street food vendors across India.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
