import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { getAuthHeaders } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/layout/navbar";
import { 
  Package, 
  Plus, 
  Edit, 
  Search, 
  IndianRupee,
  AlertTriangle,
  CheckCircle,
  Eye,
  EyeOff
} from "lucide-react";

export default function SupplierInventory() {
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<any>(null);
  const [formData, setFormData] = useState({
    materialId: "",
    pricePerUnit: "",
    availableQuantity: "",
    minOrderQuantity: "1",
  });
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: inventory, isLoading: inventoryLoading } = useQuery({
    queryKey: ["/api/supplier/inventory"],
    queryFn: async () => {
      const response = await fetch("/api/supplier/inventory", {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch inventory");
      return response.json();
    },
  });

  const { data: materials, isLoading: materialsLoading } = useQuery({
    queryKey: ["/api/materials"],
    queryFn: async () => {
      const response = await fetch("/api/materials");
      if (!response.ok) throw new Error("Failed to fetch materials");
      return response.json();
    },
  });

  const addInventoryMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/supplier/inventory", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Product added to inventory successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/supplier/inventory"] });
      setIsAddDialogOpen(false);
      resetForm();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateInventoryMutation = useMutation({
    mutationFn: async ({ id, ...data }: any) => {
      const response = await apiRequest("PATCH", `/api/supplier/inventory/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Inventory updated successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/supplier/inventory"] });
      setEditingItem(null);
      resetForm();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setFormData({
      materialId: "",
      pricePerUnit: "",
      availableQuantity: "",
      minOrderQuantity: "1",
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const data = {
      ...formData,
      pricePerUnit: parseFloat(formData.pricePerUnit),
      availableQuantity: parseInt(formData.availableQuantity),
      minOrderQuantity: parseInt(formData.minOrderQuantity),
    };

    if (editingItem) {
      updateInventoryMutation.mutate({ id: editingItem.id, ...data });
    } else {
      addInventoryMutation.mutate(data);
    }
  };

  const handleEdit = (item: any) => {
    setEditingItem(item);
    setFormData({
      materialId: item.materialId,
      pricePerUnit: item.pricePerUnit.toString(),
      availableQuantity: item.availableQuantity.toString(),
      minOrderQuantity: item.minOrderQuantity?.toString() || "1",
    });
  };

  const toggleActive = (item: any) => {
    updateInventoryMutation.mutate({
      id: item.id,
      isActive: !item.isActive,
    });
  };

  const filteredInventory = inventory?.filter((item: any) =>
    item.material?.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.material?.category.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const getStockStatus = (quantity: number) => {
    if (quantity === 0) return { label: 'Out of Stock', color: 'bg-destructive text-white' };
    if (quantity < 5) return { label: 'Critical', color: 'bg-destructive text-white' };
    if (quantity < 10) return { label: 'Low Stock', color: 'bg-warning text-white' };
    return { label: 'In Stock', color: 'bg-secondary text-white' };
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Inventory Management</h1>
            <p className="text-gray-600">Manage your product listings and availability</p>
          </div>
          
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-secondary hover:bg-green-600 mt-4 sm:mt-0" data-testid="button-add-product">
                <Plus className="mr-2 h-4 w-4" />
                Add Product
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Add New Product</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="material">Material</Label>
                  <Select 
                    value={formData.materialId} 
                    onValueChange={(value) => setFormData({...formData, materialId: value})}
                    required
                  >
                    <SelectTrigger data-testid="select-material">
                      <SelectValue placeholder="Select material" />
                    </SelectTrigger>
                    <SelectContent>
                      {materials?.map((material: any) => (
                        <SelectItem key={material.id} value={material.id}>
                          {material.name} ({material.unit})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="pricePerUnit">Price per Unit (₹)</Label>
                  <Input
                    id="pricePerUnit"
                    type="number"
                    step="0.01"
                    placeholder="Enter price"
                    value={formData.pricePerUnit}
                    onChange={(e) => setFormData({...formData, pricePerUnit: e.target.value})}
                    required
                    data-testid="input-price"
                  />
                </div>
                
                <div>
                  <Label htmlFor="availableQuantity">Available Quantity</Label>
                  <Input
                    id="availableQuantity"
                    type="number"
                    placeholder="Enter quantity"
                    value={formData.availableQuantity}
                    onChange={(e) => setFormData({...formData, availableQuantity: e.target.value})}
                    required
                    data-testid="input-quantity"
                  />
                </div>
                
                <div>
                  <Label htmlFor="minOrderQuantity">Minimum Order Quantity</Label>
                  <Input
                    id="minOrderQuantity"
                    type="number"
                    placeholder="Enter minimum order"
                    value={formData.minOrderQuantity}
                    onChange={(e) => setFormData({...formData, minOrderQuantity: e.target.value})}
                    data-testid="input-min-order"
                  />
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full bg-secondary hover:bg-green-600"
                  disabled={addInventoryMutation.isPending}
                  data-testid="button-save-product"
                >
                  {addInventoryMutation.isPending ? "Adding..." : "Add Product"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Search */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <Input
                type="text"
                placeholder="Search products by name or category..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search-inventory"
              />
            </div>
          </CardContent>
        </Card>

        {/* Inventory Grid */}
        {inventoryLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <div className="animate-pulse">
                    <div className="bg-gray-200 rounded h-6 mb-3"></div>
                    <div className="bg-gray-200 rounded h-4 mb-2"></div>
                    <div className="bg-gray-200 rounded h-4 w-2/3"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredInventory.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredInventory.map((item: any) => {
              const stockStatus = getStockStatus(item.availableQuantity);
              return (
                <Card key={item.id} className={`hover:shadow-md transition-shadow duration-200 ${!item.isActive ? 'opacity-60' : ''}`}>
                  <CardHeader className="pb-4">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center space-x-2">
                        <Package className="h-5 w-5 text-primary" />
                        <CardTitle className="text-lg">{item.material?.name}</CardTitle>
                      </div>
                      <Badge className={stockStatus.color}>
                        {stockStatus.label}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Price:</span>
                        <div className="flex items-center font-semibold text-lg">
                          <IndianRupee className="h-4 w-4" />
                          <span>{parseFloat(item.pricePerUnit).toFixed(2)}</span>
                          <span className="text-sm text-gray-500 ml-1">/{item.material?.unit}</span>
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Available:</span>
                        <span className="font-medium">
                          {item.availableQuantity} {item.material?.unit}
                        </span>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Min Order:</span>
                        <span className="font-medium">
                          {item.minOrderQuantity || 1} {item.material?.unit}
                        </span>
                      </div>
                      
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${
                            item.availableQuantity === 0 ? 'bg-destructive' :
                            item.availableQuantity < 5 ? 'bg-destructive' :
                            item.availableQuantity < 10 ? 'bg-warning' : 'bg-secondary'
                          }`}
                          style={{ width: `${Math.min((item.availableQuantity / 20) * 100, 100)}%` }}
                        ></div>
                      </div>
                      
                      <div className="flex space-x-2 pt-2">
                        <Button 
                          size="sm" 
                          variant="outline" 
                          onClick={() => handleEdit(item)}
                          className="flex-1"
                          data-testid={`button-edit-${item.id}`}
                        >
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          onClick={() => toggleActive(item)}
                          className={item.isActive ? 'text-gray-600' : 'text-secondary'}
                          data-testid={`button-toggle-${item.id}`}
                        >
                          {item.isActive ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card>
            <CardContent className="p-12">
              <div className="text-center text-gray-500">
                <Package className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No products found</h3>
                <p className="text-gray-600 mb-4">
                  {searchQuery 
                    ? "No products match your search criteria" 
                    : "Start by adding your first product to inventory"}
                </p>
                {!searchQuery && (
                  <Button 
                    onClick={() => setIsAddDialogOpen(true)}
                    className="bg-secondary hover:bg-green-600"
                    data-testid="button-add-first-product"
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Add Your First Product
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Edit Dialog */}
        <Dialog open={!!editingItem} onOpenChange={() => setEditingItem(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Edit Product</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>Material</Label>
                <Input
                  value={editingItem?.material?.name || ""}
                  disabled
                  className="bg-gray-100"
                />
              </div>
              
              <div>
                <Label htmlFor="editPricePerUnit">Price per Unit (₹)</Label>
                <Input
                  id="editPricePerUnit"
                  type="number"
                  step="0.01"
                  placeholder="Enter price"
                  value={formData.pricePerUnit}
                  onChange={(e) => setFormData({...formData, pricePerUnit: e.target.value})}
                  required
                  data-testid="input-edit-price"
                />
              </div>
              
              <div>
                <Label htmlFor="editAvailableQuantity">Available Quantity</Label>
                <Input
                  id="editAvailableQuantity"
                  type="number"
                  placeholder="Enter quantity"
                  value={formData.availableQuantity}
                  onChange={(e) => setFormData({...formData, availableQuantity: e.target.value})}
                  required
                  data-testid="input-edit-quantity"
                />
              </div>
              
              <div>
                <Label htmlFor="editMinOrderQuantity">Minimum Order Quantity</Label>
                <Input
                  id="editMinOrderQuantity"
                  type="number"
                  placeholder="Enter minimum order"
                  value={formData.minOrderQuantity}
                  onChange={(e) => setFormData({...formData, minOrderQuantity: e.target.value})}
                  data-testid="input-edit-min-order"
                />
              </div>
              
              <div className="flex space-x-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setEditingItem(null)}
                  className="flex-1"
                  data-testid="button-cancel-edit"
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  className="flex-1 bg-secondary hover:bg-green-600"
                  disabled={updateInventoryMutation.isPending}
                  data-testid="button-save-changes"
                >
                  {updateInventoryMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
