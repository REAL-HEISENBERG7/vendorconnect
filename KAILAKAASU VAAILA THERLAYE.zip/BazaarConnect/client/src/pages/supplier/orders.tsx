import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { getAuthHeaders } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/layout/navbar";
import OrderTracking from "@/components/order-tracking";
import { 
  Search, 
  Package, 
  Clock, 
  Truck, 
  CheckCircle, 
  AlertCircle,
  Calendar,
  IndianRupee,
  Phone,
  User,
  MapPin
} from "lucide-react";

export default function SupplierOrders() {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: orders, isLoading } = useQuery({
    queryKey: ["/api/orders"],
    queryFn: async () => {
      const response = await fetch("/api/orders", {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch orders");
      return response.json();
    },
  });

  const updateOrderMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const response = await apiRequest("PATCH", `/api/orders/${id}`, { status });
      return response.json();
    },
    onSuccess: (_, variables) => {
      toast({
        title: "Success",
        description: `Order ${variables.status === 'confirmed' ? 'accepted' : variables.status} successfully!`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const filteredOrders = orders?.filter((order: any) => {
    const matchesSearch = order.material?.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         order.vendor?.businessName?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || order.status === statusFilter;
    return matchesSearch && matchesStatus;
  }) || [];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'delivered': return 'bg-secondary text-white';
      case 'shipped': return 'bg-warning text-white';
      case 'confirmed': return 'bg-accent text-white';
      case 'pending': return 'bg-gray-500 text-white';
      case 'cancelled': return 'bg-destructive text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'delivered': return <CheckCircle className="h-4 w-4" />;
      case 'shipped': return <Truck className="h-4 w-4" />;
      case 'confirmed': return <Package className="h-4 w-4" />;
      case 'pending': return <Clock className="h-4 w-4" />;
      case 'cancelled': return <AlertCircle className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const handleUpdateStatus = (orderId: string, newStatus: string) => {
    updateOrderMutation.mutate({ id: orderId, status: newStatus });
  };

  if (selectedOrder) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-6">
            <Button 
              variant="outline" 
              onClick={() => setSelectedOrder(null)}
              data-testid="button-back-to-orders"
            >
              ← Back to Orders
            </Button>
          </div>
          <OrderTracking order={selectedOrder} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Order Management</h1>
          <p className="text-gray-600">Process and track customer orders</p>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  type="text"
                  placeholder="Search orders by material or vendor..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                  data-testid="input-search-orders"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-48" data-testid="select-status-filter">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Orders</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="confirmed">Confirmed</SelectItem>
                  <SelectItem value="shipped">Shipped</SelectItem>
                  <SelectItem value="delivered">Delivered</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Orders List */}
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <div className="animate-pulse">
                    <div className="bg-gray-200 rounded h-6 mb-3 w-1/3"></div>
                    <div className="bg-gray-200 rounded h-4 mb-2 w-1/2"></div>
                    <div className="bg-gray-200 rounded h-4 w-1/4"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredOrders.length > 0 ? (
          <div className="space-y-4">
            {filteredOrders.map((order: any) => (
              <Card 
                key={order.id} 
                className="hover:shadow-md transition-shadow duration-200"
                data-testid={`order-card-${order.id}`}
              >
                <CardContent className="p-6">
                  <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center space-y-4 lg:space-y-0">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-3">
                        <div className="bg-primary/10 rounded-lg p-2">
                          <Package className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            {order.material?.name} - {order.quantity}{order.material?.unit}
                          </h3>
                          <p className="text-sm text-gray-600">
                            Order #{order.id.slice(-8).toUpperCase()}
                          </p>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2 text-sm text-gray-600">
                            <User className="h-4 w-4" />
                            <span>{order.vendor?.businessName || "Unknown Vendor"}</span>
                          </div>
                          {order.vendor?.contactNumber && (
                            <div className="flex items-center space-x-2 text-sm text-gray-600">
                              <Phone className="h-4 w-4" />
                              <span>{order.vendor.contactNumber}</span>
                            </div>
                          )}
                        </div>
                        
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2 text-sm text-gray-600">
                            <Calendar className="h-4 w-4" />
                            <span>Ordered: {new Date(order.createdAt).toLocaleDateString()}</span>
                          </div>
                          {order.estimatedDelivery && (
                            <div className="flex items-center space-x-2 text-sm text-gray-600">
                              <Clock className="h-4 w-4" />
                              <span>Expected: {new Date(order.estimatedDelivery).toLocaleDateString()}</span>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      {order.deliveryAddress && (
                        <div className="flex items-start space-x-2 text-sm text-gray-600 mb-3">
                          <MapPin className="h-4 w-4 mt-0.5" />
                          <span>{order.deliveryAddress}</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex flex-col items-end space-y-3">
                      <Badge className={`${getStatusColor(order.status)} flex items-center space-x-1`}>
                        {getStatusIcon(order.status)}
                        <span className="capitalize">{order.status}</span>
                      </Badge>
                      
                      <div className="text-right">
                        <div className="flex items-center text-2xl font-bold text-gray-900">
                          <IndianRupee className="h-5 w-5" />
                          <span>{parseFloat(order.totalAmount).toFixed(2)}</span>
                        </div>
                        <p className="text-sm text-gray-500">
                          ₹{parseFloat(order.pricePerUnit).toFixed(2)} per {order.material?.unit}
                        </p>
                      </div>
                      
                      <div className="flex flex-col sm:flex-row gap-2">
                        {order.status === 'pending' && (
                          <>
                            <Button 
                              size="sm" 
                              className="bg-secondary hover:bg-green-600"
                              onClick={() => handleUpdateStatus(order.id, 'confirmed')}
                              disabled={updateOrderMutation.isPending}
                              data-testid={`button-accept-${order.id}`}
                            >
                              Accept
                            </Button>
                            <Button 
                              size="sm" 
                              variant="destructive"
                              onClick={() => handleUpdateStatus(order.id, 'cancelled')}
                              disabled={updateOrderMutation.isPending}
                              data-testid={`button-decline-${order.id}`}
                            >
                              Decline
                            </Button>
                          </>
                        )}
                        
                        {order.status === 'confirmed' && (
                          <Button 
                            size="sm" 
                            className="bg-warning hover:bg-yellow-600"
                            onClick={() => handleUpdateStatus(order.id, 'shipped')}
                            disabled={updateOrderMutation.isPending}
                            data-testid={`button-ship-${order.id}`}
                          >
                            <Truck className="h-4 w-4 mr-1" />
                            Ship Order
                          </Button>
                        )}
                        
                        {order.status === 'shipped' && (
                          <Button 
                            size="sm" 
                            className="bg-secondary hover:bg-green-600"
                            onClick={() => handleUpdateStatus(order.id, 'delivered')}
                            disabled={updateOrderMutation.isPending}
                            data-testid={`button-deliver-${order.id}`}
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Mark Delivered
                          </Button>
                        )}
                        
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => setSelectedOrder(order)}
                          data-testid={`button-track-${order.id}`}
                        >
                          Track Order
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="p-12">
              <div className="text-center text-gray-500">
                <Package className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No orders found</h3>
                <p className="text-gray-600 mb-4">
                  {searchQuery || statusFilter !== "all" 
                    ? "No orders match your current filters" 
                    : "You haven't received any orders yet"}
                </p>
                {!searchQuery && statusFilter === "all" && (
                  <p className="text-sm text-gray-500">
                    Make sure your inventory is up to date to start receiving orders
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
