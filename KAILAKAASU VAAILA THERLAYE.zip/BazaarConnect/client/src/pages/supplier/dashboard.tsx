import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { getAuthHeaders } from "@/lib/auth";
import { useAuth } from "@/hooks/use-auth";
import Navbar from "@/components/layout/navbar";
import { Link } from "wouter";
import { 
  Package, 
  TrendingUp, 
  Star, 
  ShoppingCart,
  Plus, 
  List, 
  ChartLine,
  IndianRupee,
  Clock,
  AlertCircle,
  CheckCircle,
  Truck
} from "lucide-react";

export default function SupplierDashboard() {
  const { user } = useAuth();

  const { data: analytics, isLoading: analyticsLoading } = useQuery({
    queryKey: [`/api/analytics/supplier/${user?.id}`],
    queryFn: async () => {
      const response = await fetch(`/api/analytics/supplier/${user?.id}`, {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch analytics");
      return response.json();
    },
    enabled: !!user?.id,
  });

  const { data: orders, isLoading: ordersLoading } = useQuery({
    queryKey: ["/api/orders"],
    queryFn: async () => {
      const response = await fetch("/api/orders", {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch orders");
      return response.json();
    },
  });

  const { data: inventory, isLoading: inventoryLoading } = useQuery({
    queryKey: ["/api/supplier/inventory"],
    queryFn: async () => {
      const response = await fetch("/api/supplier/inventory", {
        headers: getAuthHeaders(),
      });
      if (!response.ok) throw new Error("Failed to fetch inventory");
      return response.json();
    },
  });

  const pendingOrders = orders?.filter((order: any) => order.status === 'pending') || [];
  const recentOrders = orders?.slice(0, 3) || [];
  const lowStockItems = inventory?.filter((item: any) => item.availableQuantity < 10) || [];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'delivered': return 'bg-secondary text-white';
      case 'shipped': return 'bg-warning text-white';
      case 'confirmed': return 'bg-accent text-white';
      case 'pending': return 'bg-gray-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'delivered': return <CheckCircle className="h-4 w-4" />;
      case 'shipped': return <Truck className="h-4 w-4" />;
      case 'confirmed': return <Package className="h-4 w-4" />;
      case 'pending': return <Clock className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Welcome back, {user?.businessName || user?.username}!
            </h1>
            <p className="text-gray-600">Manage your inventory and fulfill vendor orders</p>
          </div>
          <Link href="/inventory">
            <Button className="mt-4 lg:mt-0 bg-secondary hover:bg-green-600" data-testid="button-add-product">
              <Plus className="mr-2 h-4 w-4" />
              Add Product
            </Button>
          </Link>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-r from-secondary to-green-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100 text-sm font-medium">Active Orders</p>
                  <p className="text-3xl font-bold" data-testid="stat-active-orders">
                    {analyticsLoading ? "-" : analytics?.activeOrders || 0}
                  </p>
                </div>
                <ShoppingCart className="h-8 w-8 text-green-200" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-r from-primary to-orange-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-100 text-sm font-medium">Monthly Revenue</p>
                  <p className="text-3xl font-bold" data-testid="stat-monthly-revenue">
                    ₹{analyticsLoading ? "-" : analytics?.monthlyRevenue?.toLocaleString() || 0}
                  </p>
                </div>
                <TrendingUp className="h-8 w-8 text-orange-200" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-r from-accent to-blue-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100 text-sm font-medium">Products Listed</p>
                  <p className="text-3xl font-bold" data-testid="stat-products">
                    {analyticsLoading ? "-" : analytics?.products || 0}
                  </p>
                </div>
                <Package className="h-8 w-8 text-blue-200" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-sm font-medium">Rating</p>
                  <p className="text-3xl font-bold" data-testid="stat-rating">
                    {analyticsLoading ? "-" : analytics?.rating || "4.8★"}
                  </p>
                </div>
                <Star className="h-8 w-8 text-purple-200" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Pending Orders */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-gray-900">Pending Orders</h3>
                <Link href="/orders" className="text-secondary hover:text-green-600 text-sm font-medium" data-testid="link-view-all-orders">
                  View All
                </Link>
              </div>
              
              {ordersLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="animate-pulse">
                      <div className="bg-gray-200 rounded-lg p-4 h-24"></div>
                    </div>
                  ))}
                </div>
              ) : pendingOrders.length > 0 ? (
                <div className="space-y-4">
                  {pendingOrders.slice(0, 3).map((order: any) => (
                    <div 
                      key={order.id} 
                      className="bg-gray-50 rounded-lg p-4 border-l-4 border-warning"
                      data-testid={`pending-order-${order.id}`}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h4 className="font-medium text-gray-900">
                            {order.material?.name} - {order.quantity}{order.material?.unit}
                          </h4>
                          <p className="text-sm text-gray-600">{order.vendor?.businessName}</p>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center text-lg font-semibold text-gray-900">
                            <IndianRupee className="h-4 w-4" />
                            <span>{parseFloat(order.totalAmount).toFixed(2)}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex justify-between items-center mt-3">
                        <p className="text-sm text-gray-500">
                          {new Date(order.createdAt).toLocaleString()}
                        </p>
                        <div className="flex space-x-2">
                          <Button size="sm" className="bg-secondary hover:bg-green-600" data-testid={`button-accept-${order.id}`}>
                            Accept
                          </Button>
                          <Button size="sm" variant="destructive" data-testid={`button-decline-${order.id}`}>
                            Decline
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <ShoppingCart className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                  <p>No pending orders</p>
                  <p className="text-sm">New orders will appear here</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Inventory Status */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-gray-900">Inventory Status</h3>
                <Link href="/inventory" className="text-primary hover:text-orange-600 text-sm font-medium" data-testid="link-manage-inventory">
                  Manage Inventory
                </Link>
              </div>
              
              {inventoryLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="animate-pulse">
                      <div className="bg-gray-200 rounded-lg p-4 h-20"></div>
                    </div>
                  ))}
                </div>
              ) : lowStockItems.length > 0 ? (
                <div className="space-y-4">
                  {lowStockItems.slice(0, 3).map((item: any) => (
                    <div 
                      key={item.id} 
                      className="bg-gray-50 rounded-lg p-4"
                      data-testid={`inventory-item-${item.id}`}
                    >
                      <div className="flex justify-between items-center mb-2">
                        <h4 className="font-medium text-gray-900">{item.material?.name}</h4>
                        <Badge 
                          className={item.availableQuantity < 5 ? 'bg-destructive text-white' : 'bg-warning text-white'}
                        >
                          {item.availableQuantity < 5 ? 'Critical' : 'Low Stock'}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <p className="text-sm text-gray-600">
                          Available: {item.availableQuantity}{item.material?.unit}
                        </p>
                        <div className="flex items-center text-sm font-medium text-gray-900">
                          <IndianRupee className="h-3 w-3" />
                          <span>{parseFloat(item.pricePerUnit).toFixed(2)}/{item.material?.unit}</span>
                        </div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                        <div 
                          className={`h-2 rounded-full ${item.availableQuantity < 5 ? 'bg-destructive' : 'bg-warning'}`}
                          style={{ width: `${Math.min((item.availableQuantity / 20) * 100, 100)}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <Package className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                  <p>All items in stock</p>
                  <p className="text-sm">Your inventory levels look good</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-6">Quick Actions</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Link href="/inventory">
                <Button 
                  variant="outline" 
                  className="w-full justify-start h-auto p-4 hover:border-primary"
                  data-testid="button-manage-inventory"
                >
                  <div className="bg-primary/10 rounded-lg p-3 mr-4">
                    <Package className="h-5 w-5 text-primary" />
                  </div>
                  <div className="text-left">
                    <h4 className="font-medium text-gray-900">Manage Inventory</h4>
                    <p className="text-sm text-gray-600">Add or update your products</p>
                  </div>
                </Button>
              </Link>
              
              <Link href="/orders">
                <Button 
                  variant="outline" 
                  className="w-full justify-start h-auto p-4 hover:border-secondary"
                  data-testid="button-view-orders"
                >
                  <div className="bg-secondary/10 rounded-lg p-3 mr-4">
                    <List className="h-5 w-5 text-secondary" />
                  </div>
                  <div className="text-left">
                    <h4 className="font-medium text-gray-900">View Orders</h4>
                    <p className="text-sm text-gray-600">Process customer orders</p>
                  </div>
                </Button>
              </Link>
              
              <Button 
                variant="outline" 
                className="w-full justify-start h-auto p-4 hover:border-accent"
                data-testid="button-view-analytics"
              >
                <div className="bg-accent/10 rounded-lg p-3 mr-4">
                  <ChartLine className="h-5 w-5 text-accent" />
                </div>
                <div className="text-left">
                  <h4 className="font-medium text-gray-900">View Analytics</h4>
                  <p className="text-sm text-gray-600">Business insights and reports</p>
                </div>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
